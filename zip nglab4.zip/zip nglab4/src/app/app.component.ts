import { Component } from '@angular/core';
import { BookList} from './book-interface';
import {BooklistService} from './booklist.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angularLab4';
  book:BookList[];
  constructor(private booklistService:BooklistService) {
   
   }
   getBooklist():void{
  this.booklistService.getBooklist().subscribe((book:BookList[])=>this.book=book);
}
    ngOnInit() {
    this.getBooklist();
 
  }
}

import { MultiPipePipe } from './multi-pipe.pipe';

describe('MultiPipePipe', () => {
  it('create an instance', () => {
    const pipe = new MultiPipePipe();
    expect(pipe).toBeTruthy();
  });
});

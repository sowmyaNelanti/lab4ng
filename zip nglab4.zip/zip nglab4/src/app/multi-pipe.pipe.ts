import { Pipe, PipeTransform } from '@angular/core';
import { BookList} from './book-interface';
@Pipe({
  name: 'multiPipe'
})
export class MultiPipePipe implements PipeTransform {

   transform(value: any[], arg1: any, arg2: any): BookList[] {
        if (!value || !arg1) {
            return value;
        }

        return value.filter(value =>
            value[arg2].toString().toLocaleLowerCase().indexOf(arg1.toLowerCase()) !== -1);
    }
}

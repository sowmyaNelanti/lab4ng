export interface BookList{
id:number;
author:string;
year:number;
title:string;
}
import { Injectable } from '@angular/core';
import { BookList} from './book-interface';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BooklistService {
booklistUrl='assets/booklist.json';
  constructor(private http: HttpClient) { }

  getBooklist(){
     return this.http.get<BookList[]>(this.booklistUrl)

  }
}

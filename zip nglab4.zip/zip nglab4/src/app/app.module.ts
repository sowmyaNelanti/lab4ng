import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule}  from '@angular/forms'
import {HttpClientModule} from '@angular/common/http';
import {BooklistService} from './booklist.service';

import { AppComponent } from './app.component';
import { MultiPipePipe } from './multi-pipe.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MultiPipePipe
  ],
  imports: [
    BrowserModule,HttpClientModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
